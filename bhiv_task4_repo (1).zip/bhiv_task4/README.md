# BHIV Marine Intelligence System
## Task 4 — Quantum Signal Generator
### Interface Readiness + Minimum Runnable Signal Execution

**Submitted by:** Dhiraj Chavan  
**Date:** April 2026  
**Project:** Marine Intelligence System — BHIV Core Interface Preparation

---

## What This Is

This is NOT a new system.  
This is NOT an integration with Kanishk directly.

This is the Quantum Signal Generator prepared to be:
- **callable** — one function, one contract
- **testable** — deterministic output, no randomness
- **connectable** — ready for BHIV Core to invoke

> "No system exists until it executes." — Task 4 brief

---

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/your-username/bhiv-task4-signal-generator.git
cd bhiv-task4-signal-generator

# 2. No pip install needed. Standard library only.

# 3. Run
python run_signal.py
```

**Python 3.8+ required. No external packages.**

---

## File Structure

```
bhiv-task4-signal-generator/
|
|-- run_signal.py           Phase 4 + 6: execution script + determinism proof
|-- signal_generator.py     Phase 1 + 3: callable entry point, output schema
|-- mapping_logic.py        Phase 2: deterministic state transition engine
|-- validator.py            Phase 5: input + output validation layer
|
|-- review_packets/
|   `-- task_4_review_packet.md    Phase 7: mandatory review packet
|
|-- requirements.txt        (standard library only -- no installs needed)
|-- .gitignore
`-- README.md
```

All 4 source files must be in the same folder for imports to work.

---

## The Single Callable Interface (Phase 1)

```python
from signal_generator import generate_state_event

result = generate_state_event({
    "node_id":      "qnode_01",
    "energy_delta": 0.0001,
    "iterations":   120,
    "confidence":   0.92,
    "variance":     0.002
})

print(result)
```

**Rules enforced:**
- No file I/O
- No global mutable state
- No randomness
- Same input always returns identical output

---

## Output Schema (Phase 3)

```json
{
  "engine_event_version": "2.0",
  "node_ref": "qnode_01",
  "transition": {
    "prev":  "ACTIVE",
    "next":  "CONVERGED",
    "cause": "confidence=0.92>=0.85, variance=0.002<=0.005, energy_delta=0.0001<=0.005",
    "seq":   1,
    "ts":    "2026-01-01T02:00:00Z"
  },
  "uncertainty_envelope": {
    "confidence": 0.92,
    "sigma":      0.04472136
  }
}
```

**Guarantees:**
- `sigma = sqrt(variance)` always
- `seq` is always an integer
- `ts` is always valid ISO 8601
- Output is validated before being returned

---

## State Transition Logic (Phase 2)

| Condition | Result |
|-----------|--------|
| `energy_delta > 0.01` | DIVERGED |
| `iterations > 500` | DIVERGED |
| `confidence < 0.70` | SUSPENDED |
| `variance > 0.01` | SUSPENDED |
| `confidence >= 0.85` AND `variance <= 0.005` AND `energy_delta <= 0.005` | CONVERGED |
| (fallback) | SUSPENDED |

Same input always hits the same rule. Same output every time.

---

## Validation (Phase 5)

If the input is invalid, the system **fails loudly** and returns nothing.

```python
# Missing field
generate_state_event({"node_id": "qnode_01", "iterations": 50, ...})
# ValidationError: Input validation failed (1 error(s)):
#   - Missing required field(s): ['energy_delta']

# Out-of-range value
generate_state_event({..., "confidence": 1.5, ...})
# ValidationError: Input validation failed (1 error(s)):
#   - Field 'confidence' = 1.5: must be a float in [0.0, 1.0]
```

Required fields:

| Field | Type | Constraint |
|-------|------|-----------|
| `node_id` | str | non-empty |
| `energy_delta` | float | >= 0.0 |
| `iterations` | int | >= 0 |
| `confidence` | float | in [0.0, 1.0] |
| `variance` | float | >= 0.0 |

---

## Determinism Proof (Phase 6)

```
Run 1: state=CONVERGED  sigma=0.04472136  ts=2026-01-01T02:00:00Z
Run 2: state=CONVERGED  sigma=0.04472136  ts=2026-01-01T02:00:00Z
Run 3: state=CONVERGED  sigma=0.04472136  ts=2026-01-01T02:00:00Z
Run 4: state=CONVERGED  sigma=0.04472136  ts=2026-01-01T02:00:00Z
Run 5: state=CONVERGED  sigma=0.04472136  ts=2026-01-01T02:00:00Z

RESULT: [PASS] All 5 outputs are IDENTICAL. Determinism CONFIRMED.
```

Why it is deterministic:
- No `random` module used anywhere
- No `datetime.now()` used — timestamp is computed as `anchor + (iterations * 60s)`
- Transition rules are pure functions with no side effects
- No state stored between calls

---

## Integration Block

```
THIS SYSTEM (Dhiraj)          BHIV Core (future)       Kanishk (downstream)
--------------------          ------------------       --------------------
signal_generator.py           routes + invokes         consumes validated
generate_state_event()   -->  this function       -->  events
                              (not built yet)          (DO NOT integrate
                                                        directly)
```

Raj Prajapati (Enforcement Layer) will validate execution separately.

---

## Review Packet

The mandatory review packet is at:

```
review_packets/task_4_review_packet.md
```

Covers: entry point, core flow, live input/output trace, what was built,
failure cases, and full console proof of execution.

---

## Compliance Summary

| Requirement | Status |
|-------------|--------|
| `generate_state_event(dict) -> dict` exists | PASS |
| No file I/O | PASS |
| No global mutable state | PASS |
| No randomness | PASS |
| Output matches engine_event_version 2.0 | PASS |
| `sigma = sqrt(variance)` | PASS |
| `seq` is integer | PASS |
| `ts` is valid ISO 8601 | PASS |
| Same input -> same output (5-run proof) | PASS |
| Fails loudly on invalid input | PASS |
| No event returned on invalid input | PASS |
| No orchestration / routing built | PASS |
| No Kanishk direct integration | PASS |
| Max 3 core files | PASS |
| `python run_signal.py` works from any directory | PASS |
| Review packet present | PASS |

---

*BHIV Marine Intelligence System — Task 4 — Dhiraj Chavan — April 2026*
