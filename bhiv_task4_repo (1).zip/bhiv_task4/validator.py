# -*- coding: utf-8 -*-
"""
validator.py
Input and output validation for the Quantum Signal Generator.

Validates the raw input payload BEFORE any computation occurs.
Fails loudly with a clear message describing exactly what is wrong.
Never silently accepts bad data. Never returns an event on failure.

Required input fields and constraints:
  node_id      : str   -- non-empty string
  energy_delta : float -- must be >= 0.0
  iterations   : int   -- must be >= 0
  confidence   : float -- must be in [0.0, 1.0]
  variance     : float -- must be >= 0.0
"""


# ---------------------------------------------------------------------------
# Field specification table
# ---------------------------------------------------------------------------
REQUIRED_FIELDS = {
    "node_id": {
        "type": str,
        "check": lambda v: len(v.strip()) > 0,
        "msg": "must be a non-empty string",
    },
    "energy_delta": {
        "type": float,
        "coerce": True,
        "check": lambda v: v >= 0.0,
        "msg": "must be a float >= 0.0",
    },
    "iterations": {
        "type": int,
        "check": lambda v: v >= 0,
        "msg": "must be an int >= 0",
    },
    "confidence": {
        "type": float,
        "coerce": True,
        "check": lambda v: 0.0 <= v <= 1.0,
        "msg": "must be a float in [0.0, 1.0]",
    },
    "variance": {
        "type": float,
        "coerce": True,
        "check": lambda v: v >= 0.0,
        "msg": "must be a float >= 0.0",
    },
}


# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------
class ValidationError(ValueError):
    """Raised when the input payload fails validation. Always fails loudly."""
    pass


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def validate_input(payload):
    """
    Validate and coerce the input payload.

    Args:
        payload: raw dict from the caller.

    Returns:
        cleaned dict with correct Python types.

    Raises:
        ValidationError: with a precise message for every problem found.
    """
    if not isinstance(payload, dict):
        raise ValidationError(
            "Payload must be a dict, got: " + type(payload).__name__
        )

    errors = []

    # Check for missing fields first
    missing = [f for f in REQUIRED_FIELDS if f not in payload]
    if missing:
        errors.append("Missing required field(s): " + str(missing))

    # Validate each present field
    cleaned = {}
    for field, spec in REQUIRED_FIELDS.items():
        if field not in payload:
            continue  # already flagged above

        raw = payload[field]
        typ = spec["type"]
        coerce = spec.get("coerce", False)

        # Type coercion (handles JSON numbers where int/float may vary)
        if coerce and not isinstance(raw, typ):
            try:
                raw = typ(raw)
            except (TypeError, ValueError):
                errors.append(
                    "Field '" + field + "': cannot coerce "
                    + type(raw).__name__ + " to " + typ.__name__
                )
                continue

        if not isinstance(raw, typ):
            errors.append(
                "Field '" + field + "': expected " + typ.__name__
                + ", got " + type(raw).__name__
            )
            continue

        # Range / constraint check
        if not spec["check"](raw):
            errors.append(
                "Field '" + field + "' = " + repr(raw) + ": " + spec["msg"]
            )
            continue

        cleaned[field] = raw

    if errors:
        msg = "Input validation failed (" + str(len(errors)) + " error(s)):"
        for e in errors:
            msg += "\n  - " + e
        raise ValidationError(msg)

    return cleaned


def validate_output(event):
    """
    Structural check on the generated event before it leaves the system.
    Ensures all mandatory keys are present and correctly typed.

    Raises:
        ValidationError: if the output schema is violated.
    """
    errors = []

    for k in ["engine_event_version", "node_ref", "transition", "uncertainty_envelope"]:
        if k not in event:
            errors.append("Output missing top-level key: '" + k + "'")

    if "transition" in event:
        t = event["transition"]
        for k in ["prev", "next", "cause", "seq", "ts"]:
            if k not in t:
                errors.append("transition missing key: '" + k + "'")
        if "seq" in t and not isinstance(t["seq"], int):
            errors.append(
                "transition.seq must be int, got " + type(t["seq"]).__name__
            )

    if "uncertainty_envelope" in event:
        ue = event["uncertainty_envelope"]
        for k in ["confidence", "sigma"]:
            if k not in ue:
                errors.append("uncertainty_envelope missing key: '" + k + "'")

    if errors:
        msg = "Output schema validation failed:"
        for e in errors:
            msg += "\n  - " + e
        raise ValidationError(msg)
