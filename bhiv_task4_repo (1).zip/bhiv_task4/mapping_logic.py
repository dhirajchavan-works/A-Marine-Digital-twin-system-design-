# -*- coding: utf-8 -*-
"""
mapping_logic.py
Deterministic state transition engine for the Quantum Signal Generator.

Rules are pure functions -- same input always produces same output.
No randomness. No I/O. No global state.

State space:
  CONVERGED  -- quantum node has stabilised to a valid ground state
  DIVERGED   -- node is numerically unstable or physically invalid
  SUSPENDED  -- node is in a low-confidence holding state pending retry

Transition table (priority order, first matching rule wins):

  Condition                              Next State
  ------------------------------------------------
  energy_delta > 0.01                -> DIVERGED
  iterations   > 500                 -> DIVERGED
  confidence   < 0.70                -> SUSPENDED
  variance     > 0.01                -> SUSPENDED
  confidence >= 0.85
    AND variance <= 0.005
    AND energy_delta <= 0.005        -> CONVERGED
  (fallback)                         -> SUSPENDED
"""

import math
from typing import Tuple

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------
DIVERGE_ENERGY     = 0.01    # energy_delta above this  --> DIVERGED
CONVERGE_ENERGY    = 0.005   # energy_delta at/below    --> (part of CONVERGED check)
CONFIDENCE_SUSPEND = 0.70    # confidence below this    --> SUSPENDED
CONFIDENCE_CONV    = 0.85    # confidence at/above this --> (part of CONVERGED check)
VARIANCE_SUSPEND   = 0.01    # variance above this      --> SUSPENDED
VARIANCE_CONV      = 0.005   # variance at/below        --> (part of CONVERGED check)
ITER_DIVERGE       = 500     # iterations above this    --> DIVERGED (runaway)


# ---------------------------------------------------------------------------
# Internal helpers (pure functions, no side effects)
# ---------------------------------------------------------------------------
def _infer_prev_state(payload):
    """
    Deterministically infer the previous state from the input payload.
    No stored state needed -- derived purely from iterations count.
    """
    if payload["iterations"] == 0:
        return "INITIALISING"
    return "ACTIVE"


def _determine_next_state(payload):
    # type: (dict) -> Tuple[str, str]
    """
    Apply transition rules in priority order.
    Returns (next_state, cause_string). Pure function -- no side effects.
    """
    e  = payload["energy_delta"]
    c  = payload["confidence"]
    v  = payload["variance"]
    it = payload["iterations"]

    # Rule 1: energy spike --> DIVERGED
    if e > DIVERGE_ENERGY:
        return (
            "DIVERGED",
            "energy_delta=" + str(e)
            + " exceeds diverge threshold " + str(DIVERGE_ENERGY)
        )

    # Rule 2: runaway iteration count --> DIVERGED
    if it > ITER_DIVERGE:
        return (
            "DIVERGED",
            "iterations=" + str(it)
            + " exceeds runaway limit " + str(ITER_DIVERGE)
        )

    # Rule 3: low confidence --> SUSPENDED
    if c < CONFIDENCE_SUSPEND:
        return (
            "SUSPENDED",
            "confidence=" + str(c)
            + " below suspend floor " + str(CONFIDENCE_SUSPEND)
        )

    # Rule 4: high variance --> SUSPENDED
    if v > VARIANCE_SUSPEND:
        return (
            "SUSPENDED",
            "variance=" + str(v)
            + " exceeds suspend ceiling " + str(VARIANCE_SUSPEND)
        )

    # Rule 5: all convergence criteria met --> CONVERGED
    if c >= CONFIDENCE_CONV and v <= VARIANCE_CONV and e <= CONVERGE_ENERGY:
        return (
            "CONVERGED",
            "confidence=" + str(c) + ">=" + str(CONFIDENCE_CONV)
            + ", variance=" + str(v) + "<=" + str(VARIANCE_CONV)
            + ", energy_delta=" + str(e) + "<=" + str(CONVERGE_ENERGY)
        )

    # Fallback: marginal -- hold in suspension
    return (
        "SUSPENDED",
        "marginal values: criteria not fully met for convergence"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def resolve_transition(payload, seq):
    """
    Public API consumed by signal_generator.py.

    Args:
        payload : validated input dict (node_id, energy_delta, iterations,
                  confidence, variance).
        seq     : integer sequence counter supplied by the caller.

    Returns:
        dict with keys:
          "transition": { "prev", "next", "cause", "seq" }
          "sigma"     : float  (sqrt of variance)
    """
    prev = _infer_prev_state(payload)
    next_state, cause = _determine_next_state(payload)
    sigma = math.sqrt(payload["variance"])

    return {
        "transition": {
            "prev":  prev,
            "next":  next_state,
            "cause": cause,
            "seq":   int(seq),
        },
        "sigma": sigma,
    }
