# -*- coding: utf-8 -*-
"""
signal_generator.py
Quantum Signal Generator -- callable interface for the Marine Intelligence System.

PUBLIC API (the only function BHIV Core / tests / run_signal.py will call):

    generate_state_event(input_payload: dict) -> dict

Compliance:
  - No file I/O
  - No global mutable state
  - No randomness
  - Same input always returns identical output (fully deterministic)
"""

from datetime import datetime, timezone, timedelta

import mapping_logic
import validator


def generate_state_event(input_payload):
    """
    Convert a raw quantum-node snapshot into a fully structured engine event.

    Args:
        input_payload (dict): must contain:
            node_id      (str)   -- node identifier, non-empty
            energy_delta (float) -- energy change since last iteration, >= 0
            iterations   (int)   -- VQE iteration count, >= 0
            confidence   (float) -- optimizer confidence, in [0.0, 1.0]
            variance     (float) -- output variance, >= 0

            Optional:
            seq (int) -- sequence number override (default: 1)

    Returns:
        dict: engine-compatible event matching engine_event_version 2.0.

    Raises:
        validator.ValidationError: on any invalid input. Fails loudly.
    """

    # ------------------------------------------------------------------
    # PHASE 5: Validate input before any computation
    # ------------------------------------------------------------------
    cleaned = validator.validate_input(input_payload)

    # ------------------------------------------------------------------
    # Sequence number (no global state -- read from payload or use default)
    # ------------------------------------------------------------------
    seq = int(input_payload.get("seq", 1))

    # ------------------------------------------------------------------
    # PHASE 2: Deterministic state transition
    # ------------------------------------------------------------------
    mapping    = mapping_logic.resolve_transition(cleaned, seq=seq)
    transition = mapping["transition"]
    sigma      = mapping["sigma"]

    # ------------------------------------------------------------------
    # Deterministic timestamp
    # Formula: fixed anchor 2026-01-01T00:00:00Z + (iterations * 60 seconds)
    # Guarantees: same iterations value always produces same timestamp.
    # No datetime.now() used -- zero randomness.
    # ------------------------------------------------------------------
    anchor    = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    ts_offset = timedelta(seconds=cleaned["iterations"] * 60)
    timestamp = (anchor + ts_offset).strftime("%Y-%m-%dT%H:%M:%SZ")

    # ------------------------------------------------------------------
    # PHASE 3: Build engine-compatible output (version 2.0 schema)
    # ------------------------------------------------------------------
    event = {
        "engine_event_version": "2.0",
        "node_ref": cleaned["node_id"],
        "transition": {
            "prev":  transition["prev"],
            "next":  transition["next"],
            "cause": transition["cause"],
            "seq":   transition["seq"],   # enforced int by mapping_logic
            "ts":    timestamp,           # valid ISO 8601
        },
        "uncertainty_envelope": {
            "confidence": cleaned["confidence"],
            "sigma":      round(sigma, 8),  # sigma = sqrt(variance)
        },
    }

    # ------------------------------------------------------------------
    # Validate output shape before returning
    # ------------------------------------------------------------------
    validator.validate_output(event)

    return event
