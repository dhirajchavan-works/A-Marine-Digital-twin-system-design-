# -*- coding: utf-8 -*-
"""
run_signal.py
Single execution script for the Quantum Signal Generator.

When executed:
  python run_signal.py

It will:
  1. Create a sample input payload
  2. Call generate_state_event()
  3. Print the final event output        (Phase 4)
  4. Demonstrate failure/edge cases      (Phase 5)
  5. Run the same input 5 times and
     confirm all outputs are identical   (Phase 6)

No dependencies on external systems.
No file I/O. No network calls. Runs entirely from this folder.
"""

import io
import json
import os
import sys

# ---------------------------------------------------------------------------
# PATH FIX
# Adds the folder containing run_signal.py to sys.path FIRST.
# This ensures signal_generator.py, mapping_logic.py, and validator.py
# are always found -- even when VS Code runs from a different working directory.
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# Windows terminal UTF-8 fix
# Prevents UnicodeEncodeError on cmd.exe / PowerShell.
# ---------------------------------------------------------------------------
if hasattr(sys.stdout, "buffer") and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer, encoding="utf-8", errors="replace"
    )

import signal_generator
from validator import ValidationError


# ---------------------------------------------------------------------------
# PHASE 4 -- Sample input payload (hardcoded, as permitted by task rules)
# ---------------------------------------------------------------------------
SAMPLE_INPUT = {
    "node_id":      "qnode_01",
    "energy_delta": 0.0001,
    "iterations":   120,
    "confidence":   0.92,
    "variance":     0.002,
}

# ---------------------------------------------------------------------------
# PHASE 5 -- Edge-case / failure payloads
# ---------------------------------------------------------------------------
FAILURE_INPUTS = [
    {
        "label": "Low confidence -> SUSPENDED",
        "payload": {
            "node_id":      "qnode_02",
            "energy_delta": 0.0003,
            "iterations":   80,
            "confidence":   0.55,   # below 0.70 floor -> SUSPENDED
            "variance":     0.003,
        },
    },
    {
        "label": "High energy_delta -> DIVERGED",
        "payload": {
            "node_id":      "qnode_03",
            "energy_delta": 0.05,   # above 0.01 threshold -> DIVERGED
            "iterations":   200,
            "confidence":   0.88,
            "variance":     0.001,
        },
    },
    {
        "label": "Missing field -> ValidationError",
        "payload": {
            "node_id":      "qnode_04",
            # energy_delta intentionally omitted
            "iterations":   50,
            "confidence":   0.90,
            "variance":     0.002,
        },
    },
    {
        "label": "confidence out of range -> ValidationError",
        "payload": {
            "node_id":      "qnode_05",
            "energy_delta": 0.0002,
            "iterations":   60,
            "confidence":   1.5,    # > 1.0 -> invalid
            "variance":     0.001,
        },
    },
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _line(title=""):
    bar = "-" * 60
    if title:
        print("")
        print(bar)
        print("  " + title)
        print(bar)
    else:
        print(bar)


# ---------------------------------------------------------------------------
# Phase runners
# ---------------------------------------------------------------------------
def phase_4_single_run():
    """
    PHASE 4 -- Create sample input, call generate_state_event(), print output.
    """
    _line("PHASE 4 -- Single Execution")
    print("")
    print("Input payload:")
    print(json.dumps(SAMPLE_INPUT, indent=2))
    print("")

    event = signal_generator.generate_state_event(SAMPLE_INPUT)

    print("Output event:")
    print(json.dumps(event, indent=2))
    return event


def phase_5_failure_cases():
    """
    PHASE 5 -- Validation layer: demonstrate fail-loud behaviour on bad input.
    Invalid input must NOT return an event.
    """
    _line("PHASE 5 -- Failure Cases (Validation Layer)")

    for case in FAILURE_INPUTS:
        print("")
        print("  >> " + case["label"])
        try:
            event = signal_generator.generate_state_event(case["payload"])
            # If we reach here, the state resolved (not a validation error)
            print("     result    : " + event["transition"]["next"])
            print("     cause     : " + event["transition"]["cause"])
        except ValidationError as exc:
            print("     ValidationError (expected) :")
            # Print each line of the error indented
            for line in str(exc).splitlines():
                print("       " + line)
        except Exception as exc:
            print("     UNEXPECTED ERROR: " + str(exc))


def phase_6_determinism_proof():
    """
    PHASE 6 -- Run same input 5 times. All serialised outputs must be identical.
    Returns True if determinism holds, False otherwise.
    """
    _line("PHASE 6 -- Determinism Proof  (5 runs, same input)")
    print("")

    results = []
    for i in range(1, 6):
        event      = signal_generator.generate_state_event(SAMPLE_INPUT)
        serialised = json.dumps(event, sort_keys=True)
        results.append(serialised)
        print(
            "  Run {run}: state={state:<12}  sigma={sigma}  ts={ts}".format(
                run   = i,
                state = event["transition"]["next"],
                sigma = event["uncertainty_envelope"]["sigma"],
                ts    = event["transition"]["ts"],
            )
        )

    print("")
    all_identical = all(r == results[0] for r in results)
    if all_identical:
        print("  RESULT: [PASS] All 5 outputs are IDENTICAL. Determinism CONFIRMED.")
    else:
        print("  RESULT: [FAIL] Outputs differ across runs. DETERMINISM BROKEN.")
        for i, r in enumerate(results, 1):
            print("  Run " + str(i) + ": " + r)

    return all_identical


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    print("")
    print("=" * 60)
    print("  Quantum Signal Generator -- Task 4 Execution")
    print("  Marine Intelligence System | BHIV Core Interface")
    print("=" * 60)

    phase_4_single_run()
    phase_5_failure_cases()
    deterministic = phase_6_determinism_proof()

    _line()
    print("")
    print("  EXECUTION COMPLETE")
    print("  Determinism : " + ("PASS" if deterministic else "FAIL"))
    print("")

    sys.exit(0 if deterministic else 1)


if __name__ == "__main__":
    main()
